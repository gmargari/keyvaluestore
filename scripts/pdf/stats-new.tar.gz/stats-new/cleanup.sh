#!/bin/bash

cmd="rm -rf *.log *.totalstats ./eps/"
$cmd
