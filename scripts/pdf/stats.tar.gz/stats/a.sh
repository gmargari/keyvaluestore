cp rangemerge-blocksize-0256-ord-prob-0.0.stats rangemerge-ord-prob-0.0.stats
cp rangemerge-blocksize-0256-ord-prob-0.2.stats rangemerge-ord-prob-0.2.stats
cp rangemerge-blocksize-0256-ord-prob-0.4.stats rangemerge-ord-prob-0.4.stats
cp rangemerge-blocksize-0256-ord-prob-0.6.stats rangemerge-ord-prob-0.6.stats
cp rangemerge-blocksize-0256-ord-prob-0.8.stats rangemerge-ord-prob-0.8.stats
cp rangemerge-blocksize-0256-ord-prob-1.0.stats rangemerge-ord-prob-1.0.stats
